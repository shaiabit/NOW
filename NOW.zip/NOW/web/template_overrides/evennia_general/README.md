Replace Evennia's Django templates with your own here.

You can find the original files in evennia/web/templates/evennia_general

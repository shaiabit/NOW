You can replace the theme templates for the default theme 'prosimii' here. You may wish to create a different 
theme instead, however, and update your settings accordingly.

You can find the original files in `evennia/web/templates/prosimii/`

Place your own version of templates into this file to override the default ones.
For instance, if there's a template at: `evennia/web/templates/evennia_general/index.html`
and you want to replace it, create the file `template_overrides/evennia_general/index.html`
and it will be loaded instead.
